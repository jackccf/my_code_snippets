import math

print(format('Degrees', '>10s'), end='')

# Add your code here