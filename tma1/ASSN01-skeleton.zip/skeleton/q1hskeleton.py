print('MU Name Cards')

# Add your code here