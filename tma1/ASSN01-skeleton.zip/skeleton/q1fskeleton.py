print('IAPI Analyser')

# Add your code here