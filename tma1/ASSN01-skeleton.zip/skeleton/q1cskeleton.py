print('Rate a Hotel System')
hotel = input('Enter hotel name: ')

# Add your code here
