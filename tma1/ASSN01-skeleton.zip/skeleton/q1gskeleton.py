print('Metro Chicken')

# Add your code here
