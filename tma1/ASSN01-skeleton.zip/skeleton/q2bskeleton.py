target = input('Enter target ($): ')
target = float(target)

# Add your code here