mangos = input('Enter the number of super mangos: ')

# Add your code here