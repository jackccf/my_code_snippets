something = input('Enter something: ')
print('You just entered', something, end='.')
print(' And the something is nice!')

