# Print a square on screen
size = int(input('Enter the size of the pattern: '))

# Add your code here