print('Made-to-measure seed block')

# Add your code here