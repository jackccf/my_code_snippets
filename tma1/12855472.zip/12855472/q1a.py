# assignment q1a
# purpose: to print a word “MU” in a dot-matrix format made up of asterisks
# written by Cheung Chun Fai
# On 9/11/2021
# For Assignment q1a (comp-s258, 2021Autumn)

#main code starts
print ('*       *', '*       *')
print ('**     **', '*       *')
print ('* *   * *', '*       *')
print ('*  * *  *', '*       *')
print ('*   *   *', '*       *')
print ('*       *', '*       *')
print ('*       *', ' *     * ')
print ('*       *', '  *****  ')

# for the purpose of displaying/seeing executing result
input ()