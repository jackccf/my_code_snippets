# assignment q2a
# purpose: to print out even number range from 0 ~ 500
# written by Cheung Chun Fai
# On 9/11/2021
# For Assignment q2a (comp-s258, 2021Autumn)

# main code starts

for e in range (0, 501, 2) :
    print (e, end=' ')

# for the purpose of displaying/seeing executing result
input ()