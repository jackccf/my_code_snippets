# assignment q1d
# purpose: to caculate price of super mangos purchased
# written by Cheung Chun Fai
# On 9/11/2021
# For Assignment q1d (comp-s258, 2021Autumn)

# main code starts
PRICE = 10.50 
numberOfMango = int (input ("Enter the number of super mangos: "))
totalPrice = PRICE * numberOfMango
print ("Amount to pay is", format(totalPrice, '.2f'))

# for the purpose of displaying/seeing executing result
input ()