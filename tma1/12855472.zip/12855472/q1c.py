# assignment q1c
# purpose: to rate a hotel system
# written by Cheung Chun Fai
# On 9/11/2021
# For Assignment q1c (comp-s258, 2021Autumn)

# main code starts
print ("Rate a Hotel System")
hotelName = input ("Enter hotel name:")
hotelScore = float (input ("Enter score (0-10) for the hotel: "))
print ("Thank you for given", format (hotelScore, '.1f'), "to", hotelName)

# for the purpose of displaying/seeing executing result
input ()