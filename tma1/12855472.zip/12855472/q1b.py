# assignment q1b
# purpose: to ask for input of name and print a happy birthday message for the inputed name. 
# written by Cheung Chun Fai
# On 9/11/2021
# For Assignment q1b (comp-s258, 2021Autumn)

# main code starts
name = input ("Please enter your name: ")
print ("Happy birthday to me.", "Happy birthday to me.", "Happy birthday to "+ name +".")
print ("Happy birthday to me!")

# for the purpose of displaying/seeing executing result
input ()