import random

N = int(input('Enter how many numbers in each entry (N): '))
K = int(input('Enter how many entries (K): '))

# Add input validation

# Add the remaining code here

