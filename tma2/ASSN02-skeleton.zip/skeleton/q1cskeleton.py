# Input Validation Loop
while True:
    gpa = input('Enter GPA: ')
    
    # Add code to complete the input validation loop



# After Successful Input
print('The price is ', end='')

# Add code here