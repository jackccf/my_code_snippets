# import the random module
import random
# import the time module
import time
# import the math module
import math

# probability information about the business
noOfPassenger = (1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 5500)
probabilitiesTuple = (0.01, 0.02, 0.08, 0.13, 0.18, 0.21, 0.21, 0.10, 0.04, 0.02)

def randPassenger():
    pass
    # ADD YOUR CODE HERE      



def simulateOneDay(numOfMinibus):
    pass
    # ADD YOUR CODE HERE


def findMaxProfit():
    pass
    # ADD YOUR CODE HERE



# Set a fixed random seed
random.seed(0)

# Call function to find results
findMaxProfit()
