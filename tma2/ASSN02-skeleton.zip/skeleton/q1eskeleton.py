
ratelist = [0] * 6  # create a new list and fill in 6 zeros
highest = lowest = None
average = 0

# Add your code here to do the input in a loop



print('The highest rate is {}'.format(highest))
print('The lowest rate is {}'.format(lowest))
print('The average rate is {}'.format(average))

# Add your code here to print the remaining analysis
