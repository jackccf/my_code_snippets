size = int(input('Enter size of pattern: '))

# Add your code here