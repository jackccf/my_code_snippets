def isGoodFortune(name):
    pass
    # Add your code here


print(isGoodFortune(None))
print(isGoodFortune(""))
print(isGoodFortune("GG"))
print(isGoodFortune("GGE"))

