def isLuckySeven(pwd):
    pass
    # ENTER YOUR CODE HERE


# TEST CODE
testcases1 = ['ABCDEF', 'ABCDEFGH', 'ABCDabcd', 'ABCD ']
testcases2 = ['ABCDef77@', 'ABCDef777+']

for t in testcases1:
    t = str(t)
    print(isLuckySeven(t))

for t in testcases2:
    t = str(t)
    print(isLuckySeven(t))