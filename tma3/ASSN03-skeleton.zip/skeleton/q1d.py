import sys

highestName = highestWinrate = None
countLine = 0
try:
    infile = open('EPLTeams.csv', 'r')
    while True:
        line = infile.readline()
        if line == '':
            break
    # ENTER YOUR CODE

except:
    pass
    # ENTER YOUR CODE