import math, sys

def find_pi_square(N):
    pass
    # ENTER YOUR CODER HERE

sys.setrecursionlimit(10000)
pi_square = find_pi_square(100)
pi = math.sqrt(pi_square)
print(f'PI is found to be {pi}')