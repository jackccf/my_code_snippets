
import random

def genRanList(N):
    pass
    # ENTER YOUR CODE HERE

#print(genRanList(-1)) # Test N > 0 Assert
#print(genRanList(0)) # Test N > 0 Assert
print(genRanList(10))


